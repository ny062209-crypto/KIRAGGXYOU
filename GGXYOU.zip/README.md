# GGXYOU - ម៉ាស៊ីនគិតលេខ

Android calculator (Kotlin + Jetpack Compose). White theme, colorful number buttons.
Build: `gradle assembleDebug` -> app/build/outputs/apk/debug/app-debug.apk
