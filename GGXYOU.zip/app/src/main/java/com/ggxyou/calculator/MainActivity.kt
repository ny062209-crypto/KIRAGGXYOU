package com.ggxyou.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) {
                CalculatorScreen()
            }
        }
    }
}

// ---------------------------------------------------------------- state

class CalcState {
    var expr by mutableStateOf("")
    var history by mutableStateOf("")
    var done by mutableStateOf(false)

    private val ops = "+−×÷"

    val preview: String
        get() {
            if (done || expr.isEmpty()) return ""
            val t = Calc.trimOps(expr)
            if (t.length < 2 || !t.drop(1).any { it in "+−×÷%" }) return ""
            return try {
                Calc.eval(t)
            } catch (e: Exception) {
                ""
            }
        }

    fun press(k: String) {
        when (k) {
            "C" -> startFresh()
            "←" -> {
                if (done) startFresh() else expr = expr.dropLast(1)
            }
            "=" -> equalsPressed()
            "+", "−", "×", "÷" -> operator(k)
            "%" -> percent()
            "." -> dot()
            else -> digits(k)
        }
    }

    private fun startFresh() {
        expr = ""
        history = ""
        done = false
    }

    private fun digits(k: String) {
        if (done) startFresh()
        if (expr.endsWith("%")) return
        val seg = expr.takeLastWhile { it.isDigit() || it == '.' }
        if (seg.length >= 15) return
        if (seg == "0") {
            if (k == "00") return
            expr = expr.dropLast(1) + k
            return
        }
        if (k == "00" && seg.isEmpty()) {
            expr += "0"
            return
        }
        expr += k
    }

    private fun dot() {
        if (done) startFresh()
        if (expr.endsWith("%")) return
        val seg = expr.takeLastWhile { it.isDigit() || it == '.' }
        if (seg.contains('.')) return
        expr += if (seg.isEmpty()) "0." else "."
    }

    private fun operator(k: String) {
        if (done) {
            if (expr == "Error") return
            history = ""
            done = false
        }
        if (expr.isEmpty()) {
            if (k == "−") expr = "−"
            return
        }
        val last = expr.last()
        if (last in ops) {
            if (k == "−" && (last == '×' || last == '÷')) {
                expr += k
                return
            }
            val base = Calc.trimOps(expr)
            if (base.isEmpty()) {
                if (k == "−") expr = "−"
                return
            }
            expr = base + k
            return
        }
        expr += k
    }

    private fun percent() {
        if (done) {
            if (expr == "Error") return
            history = ""
            done = false
        }
        if (expr.isNotEmpty() && (expr.last().isDigit() || expr.last() == '%')) {
            expr += "%"
        }
    }

    private fun equalsPressed() {
        if (done) return
        val t = Calc.trimOps(expr)
        if (t.isEmpty()) return
        try {
            val r = Calc.eval(t)
            history = "$t ="
            expr = r
            done = true
        } catch (e: ArithmeticException) {
            history = "$t ="
            expr = "Error"
            done = true
        } catch (e: Exception) {
            // incomplete expression: ignore
        }
    }
}

// ---------------------------------------------------------------- keys

class Key(val label: String, val color: Color)

private val KEYS: List<List<Key>> = listOf(
    listOf(Key("C", Color(0xFFE53935)), Key("←", Color(0xFF607D8B)), Key("%", Color(0xFFFF6F00)), Key("÷", Color(0xFF3949AB))),
    listOf(Key("7", Color(0xFFF4511E)), Key("8", Color(0xFFFDD835)), Key("9", Color(0xFF7CB342)), Key("×", Color(0xFFD81B60))),
    listOf(Key("4", Color(0xFF00ACC1)), Key("5", Color(0xFF1E88E5)), Key("6", Color(0xFF8E24AA)), Key("−", Color(0xFF00897B))),
    listOf(Key("1", Color(0xFFFF8A65)), Key("2", Color(0xFF4DB6AC)), Key("3", Color(0xFF9575CD)), Key("+", Color(0xFF5E35B1))),
    listOf(Key("00", Color(0xFFA1887F)), Key("0", Color(0xFF26A69A)), Key(".", Color(0xFFFFB74D)), Key("=", Color(0xFF2962FF)))
)

// ---------------------------------------------------------------- UI

@Composable
fun CalculatorScreen() {
    val state = remember { CalcState() }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Header()
        Spacer(modifier = Modifier.size(12.dp))
        Display(state, Modifier.weight(0.85f).fillMaxWidth())
        Spacer(modifier = Modifier.size(14.dp))
        Keypad(state, Modifier.weight(2.6f).fillMaxWidth())
    }
}

@Composable
fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(id = R.drawable.logo),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = stringResource(id = R.string.app_name),
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1B1F3B)
            )
            Text(
                text = "by KIRAGaming1",
                fontSize = 13.sp,
                color = Color(0xFF8A94A6)
            )
        }
    }
}

private val NUM = Regex("(\\d+)(\\.\\d*)?")

/** Adds thousands separators to display text only (the real expression is unchanged). */
fun pretty(s: String): String = NUM.replace(s) { m ->
    val grouped = m.groupValues[1].reversed().chunked(3).joinToString(",").reversed()
    grouped + m.groupValues[2]
}

/**
 * Text that first shrinks to fit the width. If it is still too long at the smallest size,
 * the oldest characters scroll off the left side (with a soft fade) so the newest digits stay visible.
 */
@Composable
fun FitText(
    text: String,
    maxSp: Int,
    minSp: Int,
    color: Color,
    weight: FontWeight,
    trimLeft: Boolean,
    fadeColor: Color,
    modifier: Modifier = Modifier
) {
    val measurer = rememberTextMeasurer()
    BoxWithConstraints(modifier = modifier) {
        val maxPx = constraints.maxWidth

        fun widthOf(t: String, size: Int): Int = measurer.measure(
            text = t,
            style = TextStyle(fontSize = size.sp, fontWeight = weight),
            softWrap = false,
            maxLines = 1
        ).size.width

        var fs = maxSp
        while (fs > minSp && widthOf(text, fs) > maxPx) fs -= 2

        var shown = text
        var trimmed = false
        if (trimLeft) {
            while (shown.length > 1 && widthOf(shown, fs) > maxPx) {
                shown = shown.drop(1)
                trimmed = true
            }
        }

        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
            Text(
                text = shown,
                fontSize = fs.sp,
                fontWeight = weight,
                color = color,
                maxLines = 1,
                softWrap = false,
                overflow = if (trimLeft) TextOverflow.Clip else TextOverflow.Ellipsis
            )
        }
        if (trimmed) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .width(36.dp)
                    .fillMaxHeight()
                    .background(Brush.horizontalGradient(listOf(fadeColor, Color.Transparent)))
            )
        }
    }
}

@Composable
fun Display(state: CalcState, modifier: Modifier) {
    val panel = Color(0xFFF3F6FC)
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(panel)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.Bottom
    ) {
        FitText(
            text = pretty(state.history),
            maxSp = 16,
            minSp = 12,
            color = Color(0xFF8A94A6),
            weight = FontWeight.Normal,
            trimLeft = true,
            fadeColor = panel,
            modifier = Modifier.fillMaxWidth().heightIn(min = 22.dp)
        )
        FitText(
            text = pretty(if (state.expr.isEmpty()) "0" else state.expr),
            maxSp = 52,
            minSp = 26,
            color = Color(0xFF1B1F3B),
            weight = FontWeight.Bold,
            trimLeft = true,
            fadeColor = panel,
            modifier = Modifier.fillMaxWidth().heightIn(min = 60.dp)
        )
        FitText(
            text = pretty(state.preview),
            maxSp = 22,
            minSp = 12,
            color = Color(0xFF7C8AA5),
            weight = FontWeight.Normal,
            trimLeft = false,
            fadeColor = panel,
            modifier = Modifier.fillMaxWidth().heightIn(min = 26.dp)
        )
    }
}

@Composable
fun Keypad(state: CalcState, modifier: Modifier) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        KEYS.forEach { row ->
            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                row.forEach { key ->
                    KeyButton(
                        key = key,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    ) { state.press(key.label) }
                }
            }
        }
    }
}

@Composable
fun KeyButton(key: Key, modifier: Modifier, onClick: () -> Unit) {
    val textColor = if (key.color.luminance() > 0.55f) Color(0xFF222222) else Color.White
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(key.color)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = key.label,
            color = textColor,
            fontSize = 28.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
