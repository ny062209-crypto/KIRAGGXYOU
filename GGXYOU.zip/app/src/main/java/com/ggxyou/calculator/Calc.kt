package com.ggxyou.calculator

import java.math.BigDecimal
import java.math.MathContext

/** Pure calculator engine: + − × ÷ and postfix %, with correct precedence. */
object Calc {
    private val MC = MathContext(14)

    fun trimOps(s: String): String = s.trimEnd('+', '−', '×', '÷')

    /** Returns the result as plain text. Throws ArithmeticException on divide by zero. */
    fun eval(expression: String): String {
        val value = Parser(expression).parse()
        return format(value)
    }

    private fun format(v: BigDecimal): String {
        val r = v.round(MC)
        if (r.signum() == 0) return "0"
        return r.stripTrailingZeros().toPlainString().replace('-', '−')
    }

    private class Parser(private val s: String) {
        private var i = 0

        fun parse(): BigDecimal {
            val v = expr()
            if (i != s.length) throw IllegalArgumentException("bad input")
            return v
        }

        private fun expr(): BigDecimal {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '−')) {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v.add(r) else v.subtract(r)
            }
            return v
        }

        private fun term(): BigDecimal {
            var v = factor()
            while (i < s.length && (s[i] == '×' || s[i] == '÷')) {
                val op = s[i++]
                val r = factor()
                v = if (op == '×') {
                    v.multiply(r, MC)
                } else {
                    if (r.signum() == 0) throw ArithmeticException("divide by zero")
                    v.divide(r, MC)
                }
            }
            return v
        }

        private fun factor(): BigDecimal {
            var negative = false
            if (i < s.length && s[i] == '−') {
                negative = true
                i++
            }
            val start = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (start == i) throw IllegalArgumentException("number expected")
            var v = BigDecimal(s.substring(start, i))
            while (i < s.length && s[i] == '%') {
                v = v.divide(BigDecimal(100), MC)
                i++
            }
            return if (negative) v.negate() else v
        }
    }
}
